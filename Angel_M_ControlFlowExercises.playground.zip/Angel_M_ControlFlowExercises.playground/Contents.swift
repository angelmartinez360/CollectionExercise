import UIKit

 
var items: [String] = ["Bikes", "Brooch", "Jewelry", "Incense", "Lip Gloss", "Phone Cases", "Rings", "Rocks", "Shoes"]
items += ["Video Game Skins"]

if items.isEmpty {
    print("Item Collection is Empty")
} else {
    print ("It is Items in your Collection")
}



print("My collection has \(items.count) items.")

let sortedString = items.sorted(by: {$0 < $1})

for item in items.sorted() {
    print(item)
}










